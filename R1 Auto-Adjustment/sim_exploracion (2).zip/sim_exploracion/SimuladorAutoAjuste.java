/*
 Universidad Autónoma de Nuevo León
 Fac. de Ingeniería Mecánica y Eléctrica
 Administración y Sistemas
 Ingeniería en Tecnologías de Software
 
 Programación de Sistemas Adaptativos
 Auto-ajuste
 Simulación donde se ajusta el estado de la visión nocturna del robot TARS (Interestelar)
*/

/*Esta clase integra el generador de percepciones con el mecanismo de auto-ajuste*/

public class SimuladorAutoAjuste
{
  public static void main(String args[])
  {
	System.out.println();
    System.out.println("=== INICIANDO SIMULADOR DE EXPLORACION PLANETARIA ===");
	System.out.println();
	System.out.println();
	
	HiloPercepcion percepcion=new HiloPercepcion(); //Generador percepciones
	percepcion.start(); //Se activa el hilo
	HiloAccion accion=new HiloAccion(percepcion); //Mecanismo de auto-ajuste
	accion.start(); //Se activa el hilo
	
  }
}