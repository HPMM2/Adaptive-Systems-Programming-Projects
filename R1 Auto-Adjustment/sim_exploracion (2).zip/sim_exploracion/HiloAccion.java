/*Esta clase maneja el monitoreo de percepciones y el mecanismo de auto-ajuste*/

public class HiloAccion extends Thread
{
	//Atributos de la clase
	private HiloPercepcion percepcion;
	private int visionNocturna; //Parámetro que se ajusta
	private static final String[] estadoVisionNocturna={"Vision Nocturna: APAGADA", "Vision Nocturna: ENCENDIDA"};

	//Constructor
	public HiloAccion(HiloPercepcion percepcion)
	{
      this.percepcion=percepcion;	 
	}
	
	//Mecanismo de ajuste
	public void realizaAjuste()
	{
	  int hora;
	  double luzSolar;
	  boolean despejado;
	  
	  Condiciones c=percepcion.getCondiciones();
	  hora=c.getHora();
	  luzSolar=c.getPorcentajeLuzSolar();
	  despejado=c.getCieloDespejado();
	  
	  /* Reglas para el ajuste */
	  if(luzSolar>=0.5 && despejado)
	   visionNocturna=0;
	  else
	   visionNocturna=1;
	   
	   despliegaStatus(hora, luzSolar, despejado);
	   
	  
	}
	
	//Este método simplemente despliega los resultados del ajuste
	public void despliegaStatus(int hora, double luzSolar, boolean despejado)
	{
		String cielo;
		
		if(despejado)
	     cielo=" cielo despejado.";
		else
		  cielo="cielo nublado.";
	   
	   System.out.println("CONDICIONES ACTUALES-- Son las " + String.valueOf(hora) + " hrs., " + String.valueOf(luzSolar) + " de luz solar y " + cielo);
	   System.out.println(estadoVisionNocturna[visionNocturna]);
	   System.out.println();
	}

  //Método que deben implementar los hilos de ejecución
  public void run()
  {    
	
    try{
		while(true)
		{
			realizaAjuste();
			sleep(2000);
		}
	}catch(InterruptedException e){
	  System.out.println(e.getMessage());
	}
  }
}