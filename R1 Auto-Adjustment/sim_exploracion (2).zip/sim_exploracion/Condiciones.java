/*Esta clase maneja las condiciones del día*/

public class Condiciones
{
  private int hora;
  private double porcentajeLuzSolar;
  private boolean cieloDespejado;
  
  public Condiciones(int horaInicial)
  {
    actualizaCondiciones(horaInicial);
  }
  
  //Método para generar un numero aleatorio dentro de un rango
  public int generaNumAleatorio(int limInf,int limSup)
  {
	  double valor;
	  Double resultado;
	  
	  valor=Math.floor(Math.random()*(limSup-limInf+1)) + limInf;
	  
	  resultado=new Double(valor);
	  
	  return resultado.intValue();
  }
  
  public void actualizaCondiciones(int hora)
  {
	 int aleatorio;
	  
    this.hora=hora;
	
	if(hora<=2 || hora>24) //0-2, 25-34
	  porcentajeLuzSolar=0;
	else if(hora>2&&hora<7||hora>20&&hora<=24) //3-6, 21-24
		porcentajeLuzSolar=0.3;
	else if(hora>=7&&hora<11||hora>=18&&hora<21) //7-10, 18-20
		porcentajeLuzSolar=0.5;
	else //11-17
		porcentajeLuzSolar=1;
	
	aleatorio=generaNumAleatorio(0,1);
	
	if(aleatorio==0)
		cieloDespejado=false;
	else
		cieloDespejado=true;
  }
  
  public boolean getCieloDespejado()
  {
	  return cieloDespejado;
  }
  
  public int getHora()
  {
	  return hora;
  }
  
  public double getPorcentajeLuzSolar()
  {
	  return porcentajeLuzSolar;
  }
}