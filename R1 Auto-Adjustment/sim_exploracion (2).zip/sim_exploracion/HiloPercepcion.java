/* Esta clase lo que va a hacer es generar percepciones (datos) cada cierto tiempo. */

public class HiloPercepcion extends Thread
{
	private Condiciones c;
	private int hora;
	
  /* Constructor */
  public HiloPercepcion()
  {
	  hora=0;
	  c=new Condiciones(hora);
  }
   
   public Condiciones getCondiciones()
   {
	   return c;
   }
   
   public void generaPercepcion()
   {
	   c.actualizaCondiciones(hora%35);
	   hora++;
   }
   
  /* Método que deben implementar todos los hilos */
  public void run()
  {
    try{
	  /* Ciclo infinito */
	  while(true)
	  {
		generaPercepcion();
	    sleep(3000);
	  }
	}catch(InterruptedException e){
	  System.out.println(e.getMessage());
	}
  }
}